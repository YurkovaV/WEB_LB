<?php
	$host = 'localhost:3306';
	$user = 'root';
	$pass = '';
	$dbName = 'museum';
?>