<?php
$host = 'localhost:3306';
$user = 'root';
$pass = '';
$dbName = 'museum';

$mysqli = new mysqli($host, $user, $pass, $dbName);

if ($mysqli->connect_error) {
    die('Ошибка подключения (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
}

function sanitize($input, $mysqli) {
    return $mysqli->real_escape_string($input);
}

if(!isset($_SESSION)) { 
    session_start(); 
} 

if ($_SERVER['REQUEST_METHOD'] == 'GET' && !empty($_GET['ID'])) {
    $id = sanitize($_GET['id'], $mysqli);

    $query = "SELECT * FROM ITEMS WHERE ID='$id'";
    $result = $mysqli->query($query);

    if ($result) {
        $row = $result->fetch_assoc();

        echo "<br>
        &nbsp;&nbsp;&nbsp;<a href='index.php?page=edit'>Редактировать</a>&nbsp;&nbsp;&nbsp;<a href='index.php?page=catalog'>Каталог</a>
        <br><br>
        <table border='1' width='80%'>
            <tr>
                <th width='20%' bgcolor='#8080ff'>Название</th>
                <td colspan='2' width='40%' style='padding:0px 0px 0px 5px;'>{$row['title']}</td>
                <td rowspan='10' width='100%'><img src='{$row['uploadlink']}</td>' ></td>
            </tr>
            <tr>
                <th width='15%' bgcolor='#8080ff'>Тип</th>
                <td colspan='2' style='padding:0px 0px 0px 5px;'>{$row['type']}</td></td>
            </tr>
            <tr>
                <th width='15%' bgcolor='#8080ff'>Местоположение</th>
                <td colspan='2' style='padding:0px 0px 0px 5px;'>{$row['location']}</td></td>
            </tr>
            <tr>
                <th width='15%' bgcolor='#8080ff'>Год</th>
                <td colspan='2' style='padding:0px 0px 0px 5px;'>{$row['rel_date']}</td></td>
            </tr>
            <tr>
                <th width='15%' bgcolor='#8080ff'>Описание</th>
                <td colspan='2' style='padding:0px 0px 0px 5px;'>{$row['description']}</td></td>
            </tr>
        </table>";
    } else {
        // Обработка ошибки запроса
        echo "Ошибка при выполнении запроса: " . $mysqli->error;
        }
    
    $result->free_result(); // Освобождаем результат запроса
    }
    
    // Закрываем соединение с MySQL
    $mysqli->close();
    ?>
    <br>