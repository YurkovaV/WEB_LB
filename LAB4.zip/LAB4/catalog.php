<button onclick="location.href='index.php?page=add';" class="add_button" style="margin-left:900px;">Добавить</button>
<form method="POST" style="display: inline;">
    <!-- <input type="submit" class="del_button" name="delete" value="Удалить" style="margin-left:10px;"> -->
</form>
<table class="data_table" border="1" style="margin-top: 20px;">
    <?php
    $host = 'localhost:3306';
    $user = 'root';
    $pass = '';
    $dbName = 'museum';

    $mysqli = new mysqli($host, $user, $pass, $dbName);

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete'])) {
        if (isset($_POST['cbs']) && !empty($_POST['cbs'])) {
            $idsToDelete = implode(',', array_map('intval', $_POST['cbs']));
            $deleteQuery = "DELETE FROM ITEMS WHERE ID IN ($idsToDelete)";
            $deleteResult = $mysqli->query($deleteQuery);

        if ($deleteResult) {
            echo "Выбранные записи успешно удалены.";
        } else {
            echo "Ошибка при удалении записей: " . $mysqli->error;
        }
    } else {
        echo "Выберите записи для удаления.";
    }
}

    $query = "SELECT * FROM ITEMS ORDER BY TITLE";
    $result = $mysqli->query($query);

    if (!$result) {
        die("Сбой при доступе к БД: " . $mysqli->error);
    }

    echo "<form method='POST'>
    <table border='1'>
        <tr>
            <th>ID</th>
            <th>Название</th>
            <th>Тип</th>
            <th>Местоположение</th>
            <th>Год</th>
            <th>Описание</th>
            <th>Изображение</th>
        </tr>";

while ($row = $result->fetch_assoc()) {
echo "<tr>
        <td>
            <input type='checkbox' name='cbs[]' value={$row['ID']} />
        </td>
        <td><a href='index.php?page=item&id={$row['ID']}'>{$row['ID']}</a></td>
        <td>{$row['TITLE']}</td>
        <td>{$row['TYPE']}</td>
        <td>{$row['LOCATION']}</td>
        <td>{$row['REL_DATE']}</td>
        <td>{$row['DESCRIPTION']}</td>
        <td><img src='" . $row['UPLOADLINK'] . "'></td>
      </tr>";
}

echo "</table>
  <input id='delete' type='submit' class='button' name='delete' value='Удалить' style='right:400px;margin-left:950px;'/></form></table>";

$mysqli->close();
?>




<br><br><br><br><br><br><br><br>