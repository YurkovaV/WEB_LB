<?php
	$menu = array(
		"Главная"=>"index.php", 
		"Работа №1"=>"index.php?page=lr1",
		"Работа №2"=>"index.php?page=lr2",
		"Работа №3"=>"index.php?page=lr3",
		"Работа №4"=>"index.php?page=lr4",
		"Каталог"=>"index.php?page=catalog");
	getMenu($menu);
?>
