<?php
	$host = 'localhost';
	$user = 'root';
	$pass = '';
	$dbName = 'museum';
?>