<table align="center">
	<tr>
		<?php date_default_timezone_set('Europe/Moscow')?>
		<td> Ваш последний визит:
		<br/> Текущее время: <?=date("d.m.Y H:i")?>
		<br/> Powered by <?=$_SERVER['SERVER_SOFTWARE']?>
		<p></p>
		</td>
	</tr>
</table>